Author: Ashley Thew, Bailey Hickman, Dhanan Patel, Ryan Youngs

Game Controls:
Left and Right arrow keys to move
Up and Down arrow keys to move up and down ladders
'A' to switch players
Space to open buttons/levers/doors